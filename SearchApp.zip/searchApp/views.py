from django.shortcuts import render
from django.http import HttpResponse
from searchApp.searchController.search import Search

# Create your views here.
def searchData(request):
    if request.method == 'GET':
        search_key = request.GET.get('keyword')
        if search_key is not None:
            print(search_key)
            search = Search()
            searchResult = search.loadJson(search_key)
            return render(request, 'search.html', {'searchResult': searchResult})
    return render(request, 'search.html')
