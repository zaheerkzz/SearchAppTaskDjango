import json
class Search:
    organizationList = []
    def __init__(self   ):
        self.organizationList.clear()

    # load data from json files on base of search keyword
    def loadJson(self, keyWord):
        # open organizations.json file and load all data
        with open('jsons/organizations.json') as organizations:
            organization = json.load(organizations)
            for data in organization:
                userInformation = {}
                if data['name'] == keyWord or str(data['_id']) == keyWord or data['external_id'] == keyWord or data['details'] == keyWord:
                    userInformation['id'] = data['_id']
                    userInformation['name'] = data['name']
                    userInformation['url'] = data['url']
                    userInformation['external_id'] = data['external_id']
                    userInformation['details'] = data['details']

                    # check for id in users
                    with open('jsons/users.json') as users:
                        user = json.load(users)
                        user_list = []
                        for user_data in user:
                            try:
                                if user_data['organization_id'] == data['_id']:
                                    user_info = {}
                                    user_info['name'] = user_data['name']
                                    user_info['alias'] = user_data['alias']
                                    user_info['phone'] = user_data['phone']
                                    user_info['email'] = user_data['email']
                                    user_info['role'] = user_data['role']
                                    user_list.append(user_info)
                            except KeyError:
                                pass
                            userInformation['user_info'] = user_list
                    # check for id in tickets
                    with open('jsons/tickets.json') as tickets:
                        ticket = json.load(tickets)
                        ticket_list = []
                        for ticket_data in ticket:
                            try:
                                if ticket_data['organization_id'] == data['_id']:
                                    ticket_info = {}
                                    ticket_info['status'] = ticket_data['status']
                                    ticket_info['description'] = ticket_data['description']
                                    ticket_info['subject'] = ticket_data['subject']
                                    ticket_info['priority'] = ticket_data['priority']
                                    ticket_info['via'] = ticket_data['via']
                                    ticket_list.append(ticket_info)
                            except KeyError:
                                pass
                            userInformation['ticket_info'] = ticket_list
                    self.organizationList.append(userInformation)
        # print(str(self.organizationList).replace("'", '"'))
        return self.organizationList
                        

    

