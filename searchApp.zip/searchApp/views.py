from django.shortcuts import render
from django.http import HttpResponse
from searchApp.search.search import Search
from searchApp.search.parsers.organizations import Organizations

# Create your views here.
def searchData(request):
    if request.method == 'GET':
        search_key = request.GET.get('keyword')
        if search_key is not None:
            search = Organizations()
            searchResult = search.loadJson(search_key)
            return render(request, 'search.html', {'searchResult': searchResult})
    return render(request, 'search.html')
