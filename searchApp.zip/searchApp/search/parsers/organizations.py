from searchApp.search.parsers.users import Users
from searchApp.search.parsers.tickets import Tickets
import json

class Organizations:
    organizationList = []
    def __init__(self   ):
        self.organizationList.clear()

    # load data from json files on base of search keyword
    def loadJson(self, keyWord):
        # open organizations.json file and load all data
        with open('jsons/organizations.json') as organizations:
            organization = json.load(organizations)
            for data in organization:
                for k,v in data.items():
                    userInformation = {}
                    if str(data[k]) == keyWord:
                        self.organizationList.append(data)
                        
                        users = Users()
                        userInformation['user_info'] = users.loadUsers(data['_id'])
                        
                        tickets = Tickets()
                        userInformation['ticket_info'] = tickets.loadTickets(data['_id'])
                        
                        self.organizationList.append(userInformation)

            return self.organizationList