import json

class Tickets:
    def loadTickets(self, data_id):
         # check for id in tickets
        with open('jsons/tickets.json') as tickets:
            ticket_ = json.load(tickets)
            ticket_list = []
            for ticket_data in ticket_:
                try:
                    if ticket_data['organization_id'] == data_id:
                        ticket_list.append(ticket_data)
                except KeyError:
                    pass
            return ticket_list
