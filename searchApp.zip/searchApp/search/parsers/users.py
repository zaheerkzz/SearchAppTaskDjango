import json

class Users:
    def loadUsers(self, data_id):
         # check for id in users
        with open('jsons/users.json') as users:
            user = json.load(users)
            user_list = []
            for user_data in user:
                try:
                    if user_data['organization_id'] == data_id:
                        user_list.append(user_data)
                except KeyError:
                    pass
            return user_list