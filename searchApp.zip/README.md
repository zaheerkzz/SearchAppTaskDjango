# SearchAppTaskDjango
Django search App task code
